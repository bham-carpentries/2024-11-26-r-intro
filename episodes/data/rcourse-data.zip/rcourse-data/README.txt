## Data

This lesson uses the [Palmer Penguins][palmerpenguinspkg] dataset. The original 
palmer penguins datasets can be found in folder `episodes/data` as files 
`penguins_raw.csv` and the simplified version `penguins.csv`. 

### License 
Data are re-used under [CC-0](https://creativecommons.org/share-your-work/public-domain/cc0/) license in accordance with the [Palmer Station LTER Data Policy](http://pal.lternet.edu/data/policies)
and the [LTER Data Access Policy for Type I data](https://lternet.edu/data-access-policy/).

### Teaching Dataset 
This course uses the file `penguins_teaching.csv` for demonstration purposes. This dataset was created from `penguins.csv` for the purposes of teaching this course using the script `episodes/data/prepare.R`. The `year` variable has been converted to text and missing values
have been replaced with their mean and modal values for convenience. 


#### See also
More information about the dataset is available in
[its official documentation](https://allisonhorst.github.io/palmerpenguins/).

## Data Citations

Gorman KB, Williams TD, Fraser WR (2014) Ecological Sexual Dimorphism and Environmental
Variability within a Community of Antarctic Penguins (Genus Pygoscelis). PLoS ONE 9(3):
e90081. https://doi.org/10.1371/journal.pone.0090081

